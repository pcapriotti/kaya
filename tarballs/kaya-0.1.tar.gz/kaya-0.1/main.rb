#!/usr/bin/env ruby
# Copyright (c) 2009 Paolo Capriotti <p.capriotti@gmail.com>
# 
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.

require '${DATA_INSTALL_DIR}/kaya/lib/kaya.rb'

start_kaya if __FILE__ == $0
